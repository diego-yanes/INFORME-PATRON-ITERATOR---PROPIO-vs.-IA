class MiscUtil:

    @staticmethod
    def hasDuplicates(v):
        i = 0
        j = 0
        duplicates = False

        for i in range(len(v) - 1):
            for j in range(i + 1, len(v)):
                if str(v[i]).lower() == str(v[j]).lower():
                    duplicates = True

        return duplicates

    # Adaptación: Java sobrecarga removeDuplicates(Vector) y
    # removeDuplicates(Vector, Vector). Python no sobrecarga por
    # número de argumentos, por lo que se usa un único método con
    # segundo parámetro opcional.
    @staticmethod
    def removeDuplicates(a, b=None):
        if b is None:
            s = a
            v = []
            for i in range(len(s)):
                duplicates = False
                for j in range(i + 1, len(s)):
                    if str(s[i]).lower() == str(s[j]).lower():
                        duplicates = True
                if duplicates == False:
                    v.append(str(s[i]).strip())
            return v
        else:
            v = []
            for i in range(len(a)):
                present = False
                for j in range(len(b)):
                    if str(a[i]).lower() == str(b[j]).lower():
                        present = True
                if not present:
                    v.append(a[i])
            return v

    @staticmethod
    def removeDuplicateDomains(s):
        i = 0
        j = 0
        duplicates = False
        str1 = ""
        str2 = ""

        v = []

        for i in range(len(s)):
            duplicates = False
            for j in range(i + 1, len(s)):
                str1 = ""
                str2 = ""
                str1 = str(s[i]).strip()
                str2 = str(s[j]).strip()
                if '@' in str1:
                    str1 = str1[str1.index('@'):]
                if '@' in str2:
                    str2 = str2[str2.index('@'):]

                if str1.lower() == str2.lower():
                    duplicates = True

            if duplicates == False:
                v.append(str(s[i]).strip())

        return v

    @staticmethod
    def areVectorsEqual(a, b):
        if len(a) != len(b):
            return False

        i = 0
        vectorSize = len(a)
        identical = True

        for i in range(vectorSize):
            if not (str(a[i]).lower() == str(b[i]).lower()):
                identical = False

        return identical