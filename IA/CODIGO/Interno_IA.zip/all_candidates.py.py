from candidate import Candidate
from file_util import FileUtil


class AllCandidates:

    def __init__(self):
        # En Java el campo nextCandidate queda implícitamente en null
        self.nextCandidate = None
        self.initialize()
        self.ec = iter(self.data)

    def initialize(self):
        # Obtener datos de la base de datos.
        self.data = []
        util = FileUtil()

        dataLines = util.fileToVector("Candidates.txt")
        for i in range(len(dataLines)):
            # Adaptación: 'str' es un builtin de Python; se renombra
            # a 'str_' para evitar shadowing (convención).
            str_ = dataLines[i]
            st = str_.split(",")
            self.data.append(
                Candidate(st[0], st[1], st[2]))

    def hasNext(self):
        matchFound = False

        self.nextCandidate = None

        # Equivalente al while + break sobre la Enumeration de Java.
        for tempObj in self.ec:
            self.nextCandidate = tempObj
            break
        return (self.nextCandidate is not None)

    def next(self):
        if self.nextCandidate is None:
            # Adaptación: NoSuchElementException (java.util) ->
            # StopIteration (excepción estándar de Python para
            # "no hay más elementos").
            raise StopIteration
        else:
            return self.nextCandidate

    def remove(self):
        pass