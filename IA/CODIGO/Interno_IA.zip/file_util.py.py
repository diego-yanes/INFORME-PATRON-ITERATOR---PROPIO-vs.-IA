import os
from misc_util import MiscUtil


class FileUtil:

    def __init__(self):
        self.dos = None

    # Método utilitario para escribir un texto dado a un archivo
    def writeToFile(self, fileName, dataLine, isAppendMode, isNewLine):
        if isNewLine:
            dataLine = "\n" + dataLine

        try:
            mode = 'a' if isAppendMode else 'w'
            self.dos = open(fileName, mode)
            self.dos.write(dataLine)
            self.dos.close()
        except (FileNotFoundError, IOError):
            return False
        return True

    # Lee datos de un archivo dado
    def readFromFile(self, fileName):
        try:
            with open(fileName, 'r') as br:
                dataLine = br.readline()
                # En Java readLine() devuelve null al EOF y "" en
                # una línea en blanco. Se replica el comportamiento.
                if dataLine == '':
                    return None
                return dataLine.rstrip('\r\n')
        except (FileNotFoundError, IOError):
            return None

    def isFileExists(self, fileName):
        return os.path.exists(fileName)

    def deleteFile(self, fileName):
        try:
            os.remove(fileName)
            return True
        except OSError:
            return False

    # Lee datos de un archivo dado hacia un Vector (lista)
    def fileToVector(self, fileName):
        v = []
        try:
            with open(fileName, 'r') as br:
                for inputLine in br:
                    v.append(inputLine.strip())
        except (FileNotFoundError, IOError):
            pass
        return v

    # Escribe datos desde un vector de entrada a un archivo dado
    def vectorToFile(self, v, fileName):
        for i in range(len(v)):
            self.writeToFile(fileName, str(v[i]), True, True)

    # Copia filas únicas de un archivo fuente a un archivo destino
    def copyUniqueElements(self, sourceFile, resultFile):
        v = self.fileToVector(sourceFile)
        v = MiscUtil.removeDuplicates(v)
        self.vectorToFile(v, resultFile)