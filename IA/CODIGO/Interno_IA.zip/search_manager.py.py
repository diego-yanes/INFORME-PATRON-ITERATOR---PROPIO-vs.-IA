import sys
import tkinter as tk

from all_candidates import AllCandidates


class buttonHandler:
    def __init__(self, inmanager=None):
        self.manager = inmanager

    # Adaptación: en Java actionPerformed recibe un ActionEvent y
    # consulta e.getActionCommand(). En tkinter no existe ese
    # objeto, por lo que se pasa directamente el comando (string).
    def actionPerformed(self, actionCommand):

        if actionCommand == SearchManager.EXIT:
            sys.exit(1)

        if actionCommand == SearchManager.SHOW_ALL:
            ac = AllCandidates()
            selectedCandidates = (
                "Name --- Cert Type --- Location" + "\n" +
                "--------------------------------------")

            while ac.hasNext():
                c = ac.next()
                selectedCandidates = (
                    selectedCandidates + "\n" +
                    c.getName() + " - " +
                    c.getCertificationType() + " - " +
                    c.getLocation())
            self.manager.setSelectedCandidates(selectedCandidates)


class SearchManager(tk.Tk):
    newline = "\n"
    SHOW_ALL = "Show Certificates"
    EXIT = "Exit"

    def __init__(self):
        super().__init__()
        self.title("Iterator Pattern - Example")

        # Crear controles
        buttonPanel = tk.Frame(self)
        panel = tk.Frame(buttonPanel)

        self.taSelectedCandidates = tk.Text(buttonPanel, height=15, width=20)
        self.taSelectedCandidates.config(state='disabled')

        # Creado pero nunca usado en el original (mismo defecto en Java)
        self.pSearchCriteria = tk.Frame(self)

        # Crear etiquetas
        lblSelectedCandidates = tk.Label(buttonPanel, text="List :")

        # Crear el botón de apertura
        btnGetSelectedCandidates = tk.Button(panel, text=SearchManager.SHOW_ALL)
        btnExit = tk.Button(panel, text=SearchManager.EXIT)

        vf = buttonHandler(self)

        btnGetSelectedCandidates.config(
            command=lambda: vf.actionPerformed(SearchManager.SHOW_ALL))
        btnExit.config(
            command=lambda: vf.actionPerformed(SearchManager.EXIT))

        # Adaptación de mnemónicos Java (Alt+S / Alt+X)
        self.bind_all('<Alt-s>',
                      lambda e: vf.actionPerformed(SearchManager.SHOW_ALL))
        self.bind_all('<Alt-x>',
                      lambda e: vf.actionPerformed(SearchManager.EXIT))

        # Con fines de diseño, colocar los botones en un panel separado
        btnGetSelectedCandidates.pack(side='left')
        btnExit.pack(side='left')
        lblSelectedCandidates.pack()
        self.taSelectedCandidates.pack()
        panel.pack()
        buttonPanel.pack()

        try:
            self.tk.call('tk', 'scaling', 1.0)
        except Exception as ex:
            print(ex)

    def setSelectedCandidates(self, selectedCandidates):
        # El JTextArea original es no editable; se emula bloqueando
        # el Text de tkinter durante la escritura.
        self.taSelectedCandidates.config(state='normal')
        self.taSelectedCandidates.delete('1.0', 'end')
        self.taSelectedCandidates.insert('1.0', selectedCandidates)
        self.taSelectedCandidates.config(state='disabled')


def main():
    # En Java main() era un método estático de SearchManager;
    # en Python se usa una función de módulo (convención).
    frame = SearchManager()
    frame.geometry("600x500")
    frame.mainloop()


if __name__ == "__main__":
    main()