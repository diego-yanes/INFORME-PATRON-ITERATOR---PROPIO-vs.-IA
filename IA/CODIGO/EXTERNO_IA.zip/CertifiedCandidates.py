class CertifiedCandidates:
    def __init__(self, inp_ac, certType):
        self.ac = inp_ac
        self.certificationType = certType
        self.ec = inp_ac.getAllCandidates()
        # En Java, nextCandidate queda en null por defecto.
        self.nextCandidate = None

    def hasNext(self):
        matchFound = False
        # Enumeration.hasMoreElements()/nextElement() -> next()/StopIteration
        while True:
            try:
                tempObj = next(self.ec)
            except StopIteration:
                break
            if tempObj.getCertificationType() == self.certificationType:
                matchFound = True
                self.nextCandidate = tempObj
                break
        if matchFound == True:
            pass
        else:
            self.nextCandidate = None
        return matchFound

    def next(self):
        if self.nextCandidate is None:
            raise StopIteration()
        else:
            return self.nextCandidate

    def remove(self):
        pass
