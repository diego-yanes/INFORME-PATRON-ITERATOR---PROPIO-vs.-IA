import sys
import tkinter as tk
from tkinter import ttk

from AllCandidates import AllCandidates

# import com.sun.java.swing.plaf.windows.*;   (Look & Feel de Windows,
# comentado en el original)


class SearchManager(tk.Tk):
    newline = "\n"
    GET_CANDIDATES = "Show Certificates"
    EXIT = "Exit"
    SUN = "Sun MicroSystems"
    APACHE = "Apache Project"
    APPLE = "Apple"

    def __init__(self):
        super().__init__()  # super("Iterator Pattern - Example");
        self.title("Iterator Pattern - Example")

        # En tkinter cada widget se crea con su contenedor padre, por lo que
        # buttonPanel y panel se crean antes que los controles.
        buttonPanel = tk.Frame(self)
        panel = tk.Frame(buttonPanel)

        # Crear controles
        self.cmbCertificationType = ttk.Combobox(buttonPanel, state="readonly")
        self.taSelectedCandidates = tk.Text(buttonPanel, height=15, width=20)
        # taSelectedCandidates.setMargin(new Insets(1,1,1,1));   (comentado)
        self.taSelectedCandidates.config(state="disabled")  # setEditable(false)

        self.pSearchCriteria = tk.Frame(self)

        self.cmbCertificationType["values"] = (
            SearchManager.SUN,
            SearchManager.APACHE,
            SearchManager.APPLE)
        self.cmbCertificationType.current(0)

        # Crear etiquetas
        lblCertificationType = tk.Label(buttonPanel, text="Certification Type:")
        lblSelectedCandidates = tk.Label(buttonPanel, text="Results:")

        # Crear el botón de abrir
        btnGetSelectedCandidates = tk.Button(panel, text=SearchManager.GET_CANDIDATES)
        # btnGetSelectedCandidates.setMnemonic(KeyEvent.VK_R);
        # (sin equivalente en tkinter)
        btnExit = tk.Button(panel, text=SearchManager.EXIT)
        # btnExit.setMnemonic(KeyEvent.VK_X);
        # (sin equivalente en tkinter)

        vf = buttonHandler(self)

        # addActionListener(vf) -> command
        btnGetSelectedCandidates.config(
            command=lambda: vf.actionPerformed(btnGetSelectedCandidates))
        btnExit.config(command=lambda: vf.actionPerformed(btnExit))

        # Por motivos de disposición, poner los botones en un panel separado

        # GridBagLayout 'gridbag2' -> grid() de tkinter
        btnGetSelectedCandidates.grid(row=0, column=0)
        btnExit.grid(row=0, column=3)

        # ****************************************************

        # Insets (top=5, bottom=5, left=5, right=5) -> padx/pady
        lblCertificationType.grid(row=0, column=0, padx=5, pady=5)
        self.cmbCertificationType.grid(row=0, column=1, sticky="w",
                                       padx=5, pady=5)
        lblSelectedCandidates.grid(row=1, column=0, sticky="w",
                                   padx=5, pady=5)
        self.taSelectedCandidates.grid(row=1, column=1, sticky="w",
                                       padx=5, pady=5)

        # insets.left=2, insets.right=2, insets.top=40 (bottom queda en 5)
        panel.grid(row=6, column=1, padx=2, pady=(40, 5))

        # ****************************************************
        # Agregar los botones y el registro a la ventana
        # contentPane.add(buttonPanel, BorderLayout.CENTER);
        buttonPanel.pack(fill="both", expand=True)

        try:
            # UIManager.setLookAndFeel(new WindowsLookAndFeel());   (comentado)
            # SwingUtilities.updateComponentTreeUI(SearchManager.this);
            # (sin equivalente en tkinter: no es necesario)
            pass
        except Exception as ex:
            print(ex)

    @staticmethod
    def main():
        frame = SearchManager()
        # windowClosing -> System.exit(0)
        frame.protocol("WM_DELETE_WINDOW", lambda: sys.exit(0))

        # frame.pack();
        frame.geometry("600x500")
        # setVisible(true) y el despacho de eventos
        frame.mainloop()

    def getCertificationType(self):
        return self.cmbCertificationType.get()

    def setSelectedCandidates(self, selectedCandidates):
        # JTextArea permite setText() aunque no sea editable; en tkinter hay
        # que habilitar temporalmente el widget Text para modificarlo.
        self.taSelectedCandidates.config(state="normal")
        self.taSelectedCandidates.delete("1.0", tk.END)
        self.taSelectedCandidates.insert(tk.END, selectedCandidates)
        self.taSelectedCandidates.config(state="disabled")


class buttonHandler:
    # En Java: public buttonHandler() {} y
    #          public buttonHandler(SearchManager inmanager).
    # Python no permite sobrecargar constructores; se unifica con un
    # parámetro opcional.
    def __init__(self, inmanager=None):
        self.manager = inmanager

    def actionPerformed(self, e=None):
        actionCommand = ""
        if e is not None:
            # e.getActionCommand() -> texto del botón
            actionCommand = e.cget("text")

        if actionCommand == SearchManager.EXIT:
            sys.exit(1)
        if actionCommand == SearchManager.GET_CANDIDATES:
            selection = self.manager.getCertificationType()
            ac = AllCandidates()
            certCandidates = ac.getCertifiedCandidates(selection)
            selectedCandidates = (
                "Name --- Cert Type --- Location" + "\n" +
                "--------------------------------------")

            while certCandidates.hasNext():
                c = certCandidates.next()
                selectedCandidates = (selectedCandidates + "\n" +
                    c.getName() + " - " + c.getCertificationType() +
                    " - " + c.getLocation())
            self.manager.setSelectedCandidates(selectedCandidates)


if __name__ == "__main__":
    SearchManager.main()
