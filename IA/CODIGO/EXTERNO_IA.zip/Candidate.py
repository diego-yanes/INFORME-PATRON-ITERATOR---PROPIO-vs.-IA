class Candidate:
    def __init__(self, inp_name, inp_certType, loc):
        self.name = inp_name
        self.certificationType = inp_certType
        self.location = loc

    def getCertificationType(self):
        return self.certificationType

    def getName(self):
        return self.name

    def getLocation(self):
        return self.location
