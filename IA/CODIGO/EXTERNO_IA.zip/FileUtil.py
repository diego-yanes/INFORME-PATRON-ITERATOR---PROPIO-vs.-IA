import os

from MiscUtil import MiscUtil


class FileUtil:

    # Método de utilidad para escribir un texto dado en un archivo
    def writeToFile(self, fileName, dataLine, isAppendMode, isNewLine):
        if isNewLine:
            dataLine = "\n" + dataLine

        try:
            # File outFile = new File(fileName);  -- la clase File no existe
            # en Python; open() recibe directamente el nombre del archivo.
            if isAppendMode:
                self.dos = open(fileName, "a")
            else:
                self.dos = open(fileName, "w")
            self.dos.write(dataLine)
            self.dos.close()
        except OSError:
            # FileNotFoundException e IOException -> OSError
            return False
        return True

    # Lee datos de un archivo dado
    def readFromFile(self, fileName):
        DataLine = ""
        try:
            br = open(fileName, "r")
            DataLine = br.readline()
            br.close()
        except OSError:
            return None
        if DataLine == "":
            # BufferedReader.readLine() devuelve null al llegar al final
            # del archivo.
            return None
        # readLine() elimina el terminador de línea.
        DataLine = DataLine.rstrip("\r\n")
        return DataLine

    def isFileExists(self, fileName):
        # new File(fileName).exists() -> os.path.exists()
        return os.path.exists(fileName)

    def deleteFile(self, fileName):
        # File.delete() devuelve false si falla; os.remove() lanza OSError.
        try:
            os.remove(fileName)
        except OSError:
            return False
        return True

    # Lee datos de un archivo dado y los carga en un Vector
    def fileToVector(self, fileName):
        v = []
        try:
            br = open(fileName, "r")
            inputLine = br.readline()
            while inputLine != "":
                v.append(inputLine.strip())
                inputLine = br.readline()
            br.close()
        # Fin del bloque try
        except OSError:
            # (bloques catch vacíos en el original: la excepción se ignora)
            pass
        return v

    # Escribe datos de un vector de entrada en un archivo dado
    def vectorToFile(self, v, fileName):
        for i in range(len(v)):
            self.writeToFile(fileName, v[i], True, True)

    # Copia filas únicas de un archivo de origen a un archivo de destino
    def copyUniqueElements(self, sourceFile, resultFile):
        v = self.fileToVector(sourceFile)
        v = MiscUtil.removeDuplicates(v)
        self.vectorToFile(v, resultFile)


# Fin de la clase FileUtil
