from Candidate import Candidate
from CertifiedCandidates import CertifiedCandidates
from FileUtil import FileUtil


class AllCandidates:
    def __init__(self):
        self.initialize()

    def initialize(self):
        # Obtener datos de la base de datos.
        self.data = []
        util = FileUtil()

        dataLines = util.fileToVector("Candidates.txt")
        for i in range(len(dataLines)):
            s = dataLines[i]
            st = s.split(",")
            self.data.append(
                Candidate(st[0], st[1], st[2]))

    def getAllCandidates(self):
        return iter(self.data)

    def getCertifiedCandidates(self, certType):
        return CertifiedCandidates(self, certType)
