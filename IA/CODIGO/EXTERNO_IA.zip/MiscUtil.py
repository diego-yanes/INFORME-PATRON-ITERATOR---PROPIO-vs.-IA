class MiscUtil:

    @staticmethod
    def hasDuplicates(v):
        i = 0
        j = 0
        duplicates = False

        for i in range(len(v) - 1):
            for j in range(i + 1, len(v)):
                if str(v[i]).lower() == str(v[j]).lower():
                    duplicates = True

        return duplicates

    @staticmethod
    def removeDuplicates(s, b=None):
        # En Java existen dos sobrecargas de removeDuplicates:
        #   removeDuplicates(Vector s)  y  removeDuplicates(Vector a, Vector b).
        # Python no permite sobrecargar métodos; se unifican con un
        # parámetro opcional.
        if b is None:
            i = 0
            j = 0
            duplicates = False

            v = []

            for i in range(len(s)):
                duplicates = False
                for j in range(i + 1, len(s)):
                    if str(s[i]).lower() == str(s[j]).lower():
                        duplicates = True

                if duplicates == False:
                    v.append(str(s[i]).strip())

            return v
        else:
            i = 0
            j = 0
            present = True
            v = []

            for i in range(len(s)):
                present = False
                for j in range(len(b)):
                    if str(s[i]).lower() == str(b[j]).lower():
                        present = True
                if not present:
                    v.append(s[i])

            return v

    @staticmethod
    def removeDuplicateDomains(s):
        i = 0
        j = 0
        duplicates = False
        str1 = ""
        str2 = ""

        v = []

        for i in range(len(s)):
            duplicates = False
            for j in range(i + 1, len(s)):
                str1 = ""
                str2 = ""
                str1 = str(s[i]).strip()
                str2 = str(s[j]).strip()
                if str1.find('@') > -1:
                    str1 = str1[str1.find('@'):]
                if str2.find('@') > -1:
                    str2 = str2[str2.find('@'):]

                if str1.lower() == str2.lower():
                    duplicates = True

            if duplicates == False:
                v.append(str(s[i]).strip())

        return v

    @staticmethod
    def areVectorsEqual(a, b):
        if len(a) != len(b):
            return False

        i = 0
        vectorSize = len(a)
        identical = True

        for i in range(vectorSize):
            if not (str(a[i]).lower() == str(b[i]).lower()):
                identical = False

        return identical


# Fin de la clase
